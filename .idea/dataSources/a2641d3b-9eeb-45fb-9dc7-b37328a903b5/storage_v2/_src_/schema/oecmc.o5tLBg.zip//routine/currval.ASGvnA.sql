create
    definer = root@`%` function currval(v_seq_name varchar(50)) returns bigint(11)
BEGIN
DECLARE value BIGINT; 
SET value = 0;
SELECT 
    CURRENT_VAL
INTO value FROM
    SEQUENCE
WHERE
    SEQ_NAME = v_seq_name; 
RETURN value; 
END;

