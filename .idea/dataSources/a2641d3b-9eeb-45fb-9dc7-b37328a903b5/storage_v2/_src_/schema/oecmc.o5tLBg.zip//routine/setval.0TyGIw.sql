create
    definer = root@`%` function setval(v_seq_name varchar(50)) returns bigint(11)
BEGIN
UPDATE SEQUENCE
SET CURRENT_VAL = value 
WHERE SEQ_NAME = v_seq_name; 
RETURN currval(v_seq_name); 
END;

